<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FeaturedCategory extends Model
{
    //
    protected $fillable = ['name','slug','image'];
}
