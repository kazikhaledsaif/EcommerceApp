<h1>Forget Password Email</h1>

You can reset password from bellow link:
<a href="{{ route('frontend.reset.password.get', $token) }}">Reset Password</a>
