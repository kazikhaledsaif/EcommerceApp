<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        Developed by
        <a href="#">Virtual Echos</a>
    </div>
    <!-- Default to the left -->
    Copyright &copy;<?php echo date("Y"); ?><strong> <a href="#"> {{ config('app.name', 'Laravel') }}</a></strong>.
    All rights reserved.
</footer>
