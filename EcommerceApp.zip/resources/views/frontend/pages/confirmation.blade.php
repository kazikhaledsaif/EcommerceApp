@extends('frontend.layouts.master')

@section('content')
    <div class="container m-5">
        <div class="row justify-content-center">
            <div class="col-sm-12 col-md-12 col-xs-12 col-lg-6 mb-30">
                <h1>Thanks for your purchase</h1>
                <p>A mail has been sent to your email</p>
            </div>
        </div>
    </div>
@endsection
