@extends('frontend.layouts.master')
@section('title' , 'Login')
@section('content')


    <!--=============================================
    =            Breadcrumb Area         =
    =============================================-->

    <div class="breadcrumb-area breadcrumb-bg pt-85 pb-85" style="background-image:  url( {{ asset('/frontend/assets/images/doozo/shop-banner.png') }})">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
{{--                    <div class="breadcrumb-container">--}}
{{--                        <ul>--}}
{{--                            <li><a href="{{route('frontend.index')}}">Home</a> <span class="separator">/</span></li>--}}
{{--                            <li class="active">Login </li>--}}
{{--                        </ul>--}}
{{--                    </div>--}}
                </div>
            </div>
        </div>
    </div>

    <!--=====  End of Breadcrumb Area  ======-->


    <!--=============================================
    =            Login Register page content         =
    =============================================-->

    <div class="page-section mb-80">
        <div class="container">
            <div class="row ">
                <div class="col-sm-12 col-md-12 col-xs-12 col-lg-6 mb-30 mx-auto">
                    <!-- Login Form s-->
                    <form method="POST" action="{{ route('frontend.login.create') }}">
                        @csrf

                        <div class="login-form">
                            <h4 class="login-title">Login</h4>

                            <div class="row">
                                <div class="col-md-12 col-12 mb-20">
                                    <label>Email Address*</label>

                                    <input  type="email" placeholder="Email Address" class="mb-0 form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}" required autofocus>

                                    @if ($errors->has('email'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                    @endif
                                </div>
                                <div class="col-12 mb-20">
                                    <label>Password</label>

                                    <input  type="password" placeholder="Password" class="mb-0 form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" required>

                                    @if ($errors->has('password'))
                                        <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                    @endif
                                </div>
                                <div class="col-md-6">

                                    <div class="check-box d-inline-block ml-0 ml-md-2 mt-10">
                                        <input class="form-check-input" type="checkbox" name="remember" id="remember_me" {{ old('remember') ? 'checked' : '' }}>
                                        <label for="remember_me">Remember me</label>
                                    </div>

                                </div>

                                <div class="col-md-6 mt-10 mb-20 text-left text-md-right">
                                    <a href="{{ route('frontend.forget.password.get') }}"> Forgotten pasward?</a>
                                    <a class="mt-2" href="{{ route('frontend.register') }}">Don't you have an account?</a>
                                </div>

                                <div class="col-md-12">
                                    <button class="register-button mt-0">Login</button>

                                </div>


                            </div>
                        </div>

                    </form>
                </div>

            </div>
        </div>
    </div>

    <!--=====  End of Login Register page content  ======-->





@endsection()
